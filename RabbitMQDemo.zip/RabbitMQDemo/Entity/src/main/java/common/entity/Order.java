package common.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class Order implements Serializable {
    private static final long serialVersionUID = -7898194272883238670L;

    private String id;  //订单ID

    private String orderCode;   //订单编码

    private String content; //订单内容
}
