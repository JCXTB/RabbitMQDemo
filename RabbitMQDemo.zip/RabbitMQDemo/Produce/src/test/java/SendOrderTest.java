import common.entity.Order;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import produce.ProduceApplication;
import produce.produce.SendOrder;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = ProduceApplication.class)
public class SendOrderTest {
    @Autowired
    private SendOrder sendOrder;

    @Test
    public void testSendOrder(){
        Order order = new Order();
        order.setId("abc123");
        order.setOrderCode("123456");
        order.setContent("订单测试内容");

        sendOrder.sendOrderInfo(order);
    }
}
