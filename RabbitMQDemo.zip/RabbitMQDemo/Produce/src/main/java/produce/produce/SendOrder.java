package produce.produce;

import common.entity.Order;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SendOrder {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void sendOrderInfo(Order order){
        rabbitTemplate.convertAndSend("orderExchange", "order.info.123456", order);
    }
}
